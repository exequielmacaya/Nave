      **¡¡HOLA!!**

_SOMOS UN GRUPO DE ENTUSISTAS POR LOS VIDEOJUEGOS Y SU CREACIÓN_

🤖 🤖 🤖 🤖

**El grupo esta compuesto por:**

💻 _Exequiel Macaya_

🖥️ _Lucas Damian Fernández_

🖱️ _Marianela Sanhueza_

📞 __
